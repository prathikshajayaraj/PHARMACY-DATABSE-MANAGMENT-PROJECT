<?php
$servername='localhost';
$username='root';
$password='';
$databasename = "pharmacy";
$conn=mysqli_connect($servername,$username,$password,$databasename);
if(!$conn)  
{
die("connection failed:".mysqli_connect_error());
}
$pharmacistid=$_GET['PHARMACIST_ID'];
$deletequery=" delete from pharmacist where PHARMACIST_ID=$pharmacistid";
$query=mysqli_query($conn,$deletequery);
if($query){
    ?>
    <script>
        alert("Deleted sucesfully");
        </script>
<?php
} else{
    ?>
    <script>
        alert(" Not Deleted");
        </script>
        <?php
}
header('location:adminviewph.php');
?>
