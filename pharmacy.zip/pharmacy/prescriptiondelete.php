<?php
$servername='localhost';
$username='root';
$password='';
$databasename = "pharmacy";
$conn=mysqli_connect($servername,$username,$password,$databasename);
if(!$conn)  
{
die("connection failed:".mysqli_connect_error());
}
$Prescription_ID=$_GET['Prescription_ID'];
$deletequery=" delete from prescription where Prescription_ID=$Prescription_ID";
$query=mysqli_query($conn,$deletequery);
if($query){
    ?>
    <script>
        alert("Deleted sucesfully");
        </script>
<?php
} else{
    ?>
    <script>
        alert(" Not Deleted");
        </script>
        <?php
}
header('location:prescriptionview.php');
?>