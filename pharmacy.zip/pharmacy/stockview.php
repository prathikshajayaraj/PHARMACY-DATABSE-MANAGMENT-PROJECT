<?php
$servername='localhost';
$username='root';
$password='';
$databasename = "pharmacy";
$conn=mysqli_connect($servername,$username,$password,$databasename);
if(!$conn)  
{
die("connection failed:".mysqli_connect_error());
}

?>
<!DOCTYPE html>
<html>
    <head>
    
        <title>Pharmacist update stocks</title>
        <?php include 'links.php' ;?>
        <link rel="stylesheet" href="style.css">
        <style>
        .ad{
            
                      position: absolute;
                       right: 100px;
                       bottom: 45px;
                       font-size: 150%;
                       background-color: black;
                       
  
  padding: 10px 15px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  
}
        </style>
      
    <body>
   <div class ="ad"> <a href="Stock.html" target="_blank">BACK</a></div>
        <div class="main-div">
            
            <h1>List of Stocks</h1>
            <div  class="center-div">
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Stock_ID</th>
                                <th>Drug_Name</th>
                                <th>Description</th>
                                <th>Supplier</th>
                                <th>Quantity</th>
                                <th>Total_Cost</th>
                                 
                                  <th>Date_Supplied</th>
                                <th>UPDATE</th>
                                <th>DELETE</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                        $selectquery="select * from stocks ";
                        $query=mysqli_query($conn,$selectquery);
                         $nums=mysqli_num_rows($query);

                         

                        while($res= mysqli_fetch_array($query))
                        {
                            ?>
                            <tr>
                            <td><?php echo $res['Stock_ID'];?></td>
                            <td><?php echo $res['Drug_Name'];?></td>
                            <td><?php echo $res['Description'];?></td>
                            <td><?php echo $res['Supplier'];?></td>
                            <td><?php echo $res['Quantity'];?></td>
                            <td><?php echo $res['Total_Cost'];?></td>
                            
                              <td><?php echo $res['Date_Supplied'];?></td>
                            
                            <td><a href="stockupdate.php?Stock_ID=<?php echo $res['Stock_ID']; ?>" data-toggle="tooltip" data-placement="bottom" title="Update"><i class="fa fa-edit" aria-hidden="true"></i></a></td>
                            <td><a href="stockdelete.php?Stock_ID=<?php echo $res['Stock_ID']; ?>" data-toggle="tooltip" data-placement="bottom" title="Delete"><i class="fa fa-trash" aria-hidden="true"></i></a></td>
                            
                           </tr>
                           <?php
                        }
                        
                         ?>
                           
                        </tbody>
                    </table>


                </div>
            </div>
        </div>
        
    </body>
    <script>
$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();
});
</script>
</html>