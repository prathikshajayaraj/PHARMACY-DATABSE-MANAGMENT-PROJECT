<?php
$servername='localhost';
$username='root';
$password='';
$databasename = "pharmacy";
$conn=mysqli_connect($servername,$username,$password,$databasename);
if(!$conn)  
{
die("connection failed:".mysqli_connect_error());
}

?>
<!DOCTYPE html>
<html>
    <head>
        <title>updatepharmacist</title>
    </head>
    <style>
      @import url( "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css");
         .center{
                   background-color:white;
                    opacity: 0.9;
                    margin: auto;
                    width : 35%;
                    border: 1px solid black;
                    padding: 10px;
                    text-align: center
         }
         .a{
                text-align: center
         } 
         body {
                       background-image: url("images/dc.jpg");
                       background-color: #cccccc;
                       height: 300px;
                       background-repeat: no-repeat;
                       background-size: cover;
                    }
                    .c{
                      text-align: relative; 
                      position: absolute;
                       right: 100px;
                       top: 45px;
                       
                    
                     }
                     a:link, a:visited {
  background-color: black;
  color: white;
  padding: 14px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  text-align: relative; 
                      position: absolute;
                       right: 100px;
                       bottom: 45px;
                       
}
                     a:active {
  background-color: black;}

    

                     

    
    </style>
       
    <body>
    <a href="adminviewph.php" target="_blank">BACK</a>
        <br><br>
        <div class="a">
        <h1>UPDATE PHARMACIST</h1>
        </div>
        <div class="c">
        <img src="images/ad.gif" alt="Computer man" style="width:280px;height:280px;">
        </div>
        <br>
        <div class="center">
        <form actions="adminaddph.php" method="post">
            <?php
            $PHARMACIST_ID=$_GET['PHARMACIST_ID'];
            $showquery ="select  * from pharmacist where PHARMACIST_ID={$PHARMACIST_ID} ";
           $showdata=mysqli_query($conn,$showquery);
           $arrdata=mysqli_fetch_array($showdata);
        if(isset($_POST['submit']))
{  
    $PHARMACISTID=$_GET['PHARMACIST_ID'];

     $PHARMACIST_ID=$_POST['PHARMACIST_ID'];
    $FIRST_NAME=$_POST['FIRST_NAME'];
     $LAST_NAME=$_POST['LAST_NAME'];
     $PHONE_NO=$_POST['PHONE_NO'];
 $EMAIL_ID=$_POST['EMAIL_ID'];

 $PASSWORD=$_POST['PASSWORD'];
    
    
/*$sql_query ="insert into pharmacist(PHARMACIST_ID,FIRST_NAME,LAST_NAME,PHONE_NO,EMAIL_ID,PASSWORD) values('$PHARMACIST_ID','$FIRST_NAME',' $LAST_NAME',' $PHONE_NO','$EMAIL_ID','$PASSWORD')";*/
$query="update pharmacist  set PHARMACIST_ID=$PHARMACIST_ID ,FIRST_NAME='$FIRST_NAME',LAST_NAME='$LAST_NAME',PHONE_NO= $PHONE_NO, EMAIL_ID='$EMAIL_ID',PASSWORD='$PASSWORD' where PHARMACIST_ID=$PHARMACISTID ";
if(mysqli_query($conn, $query))
{
echo "values updated sucesfully";
}
else 
{
echo "Error: " . $sql . ":" . mysqli_error($conn);
}
mysqli_close($conn);
}
?>
               <p>PHARMACIST_ID: <input name="PHARMACIST_ID" type="text" style="width:170px" placeholder="Pharmacist_id" required="required" id="PHARMACIST_ID" value="<?php echo $arrdata['PHARMACIST_ID'];?>"/> </p> 
                <p>FIRST NAME: <input name="FIRST_NAME" type="text" style="width:170px" placeholder="First Name" required="required" id="first_name" value="<?php echo $arrdata['FIRST_NAME'];?> " /></p>
                <p>LASTNAME: <input name="LAST_NAME" type="text" style="width:170px" placeholder="Last Name" required="required" id="last_name" value="<?php echo $arrdata['LAST_NAME'];?>"/></p>
                <p >PHONE NO: <input name="PHONE_NO" type="text" style="width:170px"placeholder="Phone"  required="required" id="phone" value="<?php echo $arrdata['PHONE_NO'];?>"/></p>  
	        <p >EMAIL_ID: <input name="EMAIL_ID" type="text" style="width:170px" placeholder="Email" required="required" id="email" value="<?php echo $arrdata['EMAIL_ID'];?>"/> </p> 
               
	        <p>PASSWORD: <input name="PASSWORD" type="text" style="width:170px" placeholder="Password" required="required" id="passwords" value="<?php echo $arrdata['PASSWORD'];?>"/></p>
          <p><input name="submit" type="submit" value="submit"/></p>
           
		</form>
        </div>
        
         
     
    
    </body>
</html>

        