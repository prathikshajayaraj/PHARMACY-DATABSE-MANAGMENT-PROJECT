<?php
$servername='localhost';
$username='root';
$password='';
$databasename = "pharmacy";
$conn=mysqli_connect($servername,$username,$password,$databasename);
if(!$conn)
{
die("connection failed:".mysqli_connect_error());
}
?>



<!Doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title> update Stock page</title>
    <style>
        a {
            color: black;
            padding: 14px 25px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
        }

        h2 {
            color: black;
        }

        .center {
            background-color: white;
            opacity: 0.8;
            margin: auto;
            width: 25%;
            border: 1px solid black;
            padding: 10px;
        }

        form {
            text-align: center
        }

        .ad {
            text-align: relative;
            position: absolute;
            right: 100px;
            top: 45px;
        }

        body {
            background-image: url("images/1.jpg");
            background-color: #cccccc;
            height: 300px;
            background-repeat: no-repeat;
            background-size: cover;
        }
         a:link, a:visited {
  background-color: black;
  color: white;
  padding: 14px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  text-align: relative; 
                      position: absolute;
                       right: 100px;
                       bottom: 45px;
                       
}
                     a:active {
  background-color: black;}
    </style>
</head>
<body>
<a href="stockview.php" target="_blank">BACK</a>
    <div class="ad">
        <h1>UPDATE STOCK</h1>
    </div>
    <br>
    <h1><strong>P</strong><small>HARMACY</small> <strong>S</strong><small>HOP</small> <strong>M</strong><small>ANAGMENT</small> <strong>S</strong><small>YSTEM</small></h1>

    <div class="s">
        <h3>A complete solution to manage Pharmacy shop</h3>
    </div>
   

    <div class="center">

    <form actions="Add_Stocks.php" method="post">
    
            <?php
            $Stock_ID=$_GET['Stock_ID'];
            $showquery ="select  * from stocks where Stock_ID={$Stock_ID} ";
           $showdata=mysqli_query($conn,$showquery);
           $arrdata=mysqli_fetch_array($showdata);
           
        if(isset($_POST['Save']))
{  
    $StockID=$_GET['Stock_ID'];


    $Drug_Name=$_POST['Drug_Name'];
     $Description=$_POST['Description'];
     $Supplier=$_POST['Supplier'];
 $Quantity=$_POST['Quantity'];

 $Total_Cost=$_POST['Total_Cost'];
 
 $Date_Supplied=$_POST['Date_Supplied'];
    
    
/*$sql_query ="insert into pharmacist(Stock_ID,Drug_Name,Description,Supplier,Quantity,Total_Cost) values('$Stock_ID','$Drug_Name',' $Description',' $Supplier','$Quantity','$Total_Cost')";*/
$query="update stocks set Stock_ID='$Stock_ID',Drug_Name='$Drug_Name',Description='$Description',Supplier='$Supplier', Quantity='$Quantity',Total_Cost='$Total_Cost',Date_Supplied='$Date_Supplied' where Stock_ID=$StockID ";
if(mysqli_query($conn, $query))
{
echo "values updated sucesfully";
}
else 
{
echo "Error: :" . mysqli_error($conn);
}
mysqli_close($conn);
}
?>
      
        <p> Stock_ID: 
        <input type="text" id="Stock_ID" name="Stock_ID" value="<?php echo $arrdata['Stock_ID'];?>"/></p>
        
        <p>Drug_Name : 
        <input type="text" id="Drug_Name" name="Drug_Name" value="<?php echo $arrdata['Drug_Name'];?>"/>
        
        <p> Description:
        <input type="text" id="Description" name="Description" value="<?php echo $arrdata['Description'];?>"/>
        
        <p> Supplier: 
        <input type="text" id="Supplier" name="Supplier" value="<?php echo $arrdata['Supplier'];?>"/></p>
        
        <p> Quantity: 
        <input type="text" id="Quantity" name="Quantity" value="<?php echo $arrdata['Quantity'];?>"/></p>

       <P> Total_Cost:
        <input type="text" id="Total_Cost" name="Total_Cost" value="<?php echo $arrdata['Total_Cost'];?>"/></p>
       
       
       
        <p> Date_Supplied:
        <input type="text" id="Date_Supplied" name="Date_Supplied" value="<?php echo $arrdata['Date_Supplied'];?>"/></p>
        

       <input type="submit" value="Save" name="Save">
    </form>
    </div>
</body>
</html>

