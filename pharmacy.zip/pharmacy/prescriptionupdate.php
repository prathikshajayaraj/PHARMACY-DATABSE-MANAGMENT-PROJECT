<?php
$servername='localhost';
$username='root';
$password='';
$databasename = "pharmacy";
$conn=mysqli_connect($servername,$username,$password,$databasename);
if(!$conn)  
{
die("connection failed:".mysqli_connect_error());
}

?>
<!DOCTYPE html>
<html>
    <head>
        <title>prescriptionupdate</title>
    </head>
    <style>
      @import url( "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css");
         .center{
                   background-color:white;
                    opacity: 0.9;
                    margin: auto;
                    width : 35%;
                    border: 1px solid black;
                    padding: 10px;
                    text-align: center
         }
         .a{
                text-align: center
         } 
         body {
                       background-image: url("images/dc.jpg");
                       background-color: #cccccc;
                       height: 300px;
                       background-repeat: no-repeat;
                       background-size: cover;
                    }
                    .c{
                      text-align: relative; 
                      position: absolute;
                       right: 100px;
                       top: 45px;
                       
                    
                     }
                     a:link, a:visited {
  background-color: black;
  color: white;
  padding: 14px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  text-align: relative; 
                      position: absolute;
                       right: 100px;
                       bottom: 45px;
                       
}
                     a:active {
  background-color: black;}

    

                     

    
    </style>
       
    <body>
    <a href="prescriptionview.php" target="_blank">BACK</a>
        <br><br>
        <div class="a">
        <h1>EDIT PRESCRIPTION</h1>
        </div>
        <div class="c">
        <img src="images/ad.gif" alt="Computer man" style="width:280px;height:280px;">
        </div>
        <br>
        <div class="center">
        <form actions="prescriptionupdate.php" method="post">
            <?php
            $Prescription_ID=$_GET['Prescription_ID'];
            $showquery ="select  * from prescription where Prescription_ID ={$Prescription_ID} ";
           $showdata=mysqli_query($conn,$showquery);
           $arrdata=mysqli_fetch_array($showdata);
        if(isset($_POST['submit']))
{  
   $Prescription_ID = $_POST['Prescription_ID'];
$Customer_Name = $_POST['Customer_Name'];
$Customer_ID=$_POST['Customer_ID'];
$Date=$_POST['Date'];
$Phone=$_POST['Phone'];
$Dose=$_POST['Dose'];
$Drug_Name=$_POST['Drug_Name'];
$Strength=$_POST['Strength'];
$Total_Amount=$_POST['Total_Amount'];

    
/*$sql_query ="insert into prescription(Prescription_ID ,Customer_Name,Customer_ID,Date,Phone,Dose,Drug_Name,Strength,Total_Amount,Quantity) values('$Prescription_ID','$Customer_Name','$Customer_ID','$Date',$Phone','$Dose','$Drug_Name','$Strength','$Total_Amount','$Quantity')";*/
$query="update prescription  set Prescription_ID='$Prescription_ID',Customer_Name='$Customer_Name',Customer_ID='$Customer_ID',Date='$Date',Phone='$Phone',Dose='$Dose',Drug_Name='$Drug_Name',Strength='$Strength',Total_Amount='$Total_Amount' where Prescription_ID ='$Prescription_ID'";
if(mysqli_query($conn, $query))
{
echo "values updated sucesfully";
}
else 
{
echo "Error: " . $sql . ":" . mysqli_error($conn);
}

}
?>
               <p>Prescription_ID: <input name="Prescription_ID" type="text" style="width:170px" placeholder="Prescription_ID" required="required" id="Prescription_ID" value="<?php echo $arrdata['Prescription_ID'];?>"/> </p> 
                <p>Customer_Name: <input name="Customer_Name" type="text" style="width:170px" placeholder="Customer_Name" required="required" id="Customer_Name" value="<?php echo $arrdata['Customer_Name'];?> " /></p>
                <p>Customer_ID : <input name="Customer_ID" type="text" style="width:170px" placeholder="Customer_ID" required="required" id="Customer_ID" value="<?php echo $arrdata['Customer_ID'];?>"/></p>
                <p >Date: <input name="Date" type="text" style="width:170px"placeholder="Date" required="required" id="Date" value="<?php echo $arrdata['Date'];?>" /></p>  
                <p>Phone: <input name="Phone" type="text" style="width:170px"placeholder="Phone"  required="required" id="Phone" value="<?php echo $arrdata['Phone'];?>"/></p>  
	        <p>Dose: <input name="Dose" type="text" style="width:170px" placeholder="Dose" required="required" id="Dose" value="<?php echo $arrdata['Dose'];?>"/> </p> 
             
          Drug Name:
           <?php
           $query=mysqli_query($conn,"select * from stocks");
           $rowcount=mysqli_num_rows($query);
           ?>
           <select name ="Drug_Name">
               <option value="">Select Any one</option>
               <?php
               for($i=1;$i<=$rowcount;$i++)
               {
                   $rows=mysqli_fetch_array($query);
              
               ?>
               <option value="<?php echo $rows["Drug_Name"] ?>"
               <?php
               if($arrdata["Drug_Name"]==$rows["Drug_Name"])
               {
                 echo "selected";
               }
               ?>
               
               ><?php echo $rows["Drug_Name"]?>
               </option>
               <?php
               }
               mysqli_close($conn);
               ?>
           </select>
               
	     
   <p>Strength: <input name="Strength" type="text" style="width:170px" placeholder="Strength" required="required" id="Strength" value="<?php echo $arrdata['Strength'];?>"/></p>
   <p>Total_Amount: <input name="Total_Amount" type="text" style="width:170px" placeholder="Total_Amount" required="required" id="Total_Amount" value="<?php echo $arrdata['Total_Amount'];?>"/></p>
  
          <p><input name="submit" type="submit" value="submit"/></p>
           
		</form>
        </div>
        
         
     
    
    </body>
</html>

        