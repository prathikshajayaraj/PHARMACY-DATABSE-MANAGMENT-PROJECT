<?php
$servername='localhost';
$username='root';
$password='';
$databasename = "pharmacy";

$conn=mysqli_connect($servername,$username,$password,$databasename);
if(!$conn)  
{
die("connection failed:".mysqli_connect_error());
}else{
    if(isset($_POST['login']))
    {
        $PHARMACIST_ID= $_POST['PHARMACIST_ID'];
        $PASSWORD = $_POST['PASSWORD'];
        $sql=mysqli_query($conn,"SELECT * FROM pharmacist where PHARMACIST_ID ='$PHARMACIST_ID' and  PASSWORD='$PASSWORD'");
        
        
        $row  = mysqli_fetch_array($sql);
        if(is_array($row))
        {
            
            $_SESSION["PHARMACIST_ID"]=$row['PHARMACIST_ID'];
            $_SESSION["PASSWORD"]=$row['PASSWORD'];
            echo "login successfull";
            header("Location:Pharmacist.php"); 
}
else 
{
echo "login unsuccessful";
header("Location:loginpharmacist.php"); 
}
mysqli_close($conn);
}
        
    }

?>
<!DOCTYPE html>
<html>
 <head>
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     <style> 
      
          h1{
              color: black;
              font-family: "Times New Roman", Times, serif;
          }
          h3{
               color: black;
               line-height: 0.1;
               font-family: Copperplate, Papyrus, fantasy;
                     
             }
          
                .center{
                    background-color:white;
                    opacity: 0.8;
                    margin: auto;
                    width : 25%;
                    border: 1px solid black;
                    padding: 10px;
                }
                
            form{
                text-align: center
                }  
                body {
                       background-image: url("images/5.jpg");
                       background-color: #cccccc;
                       height: 300px;
                       background-repeat: no-repeat;
                       background-size: cover;
                    }
                    .ad{
                      text-align: relative; 
                      position: absolute;
                       right: 100px;
                       top: 45px;

                    }
                    .btn {
  background-color:whitesmoke;
  border: none;
  color: black;
  padding: 12px 16px;
  font-size: 16px;
  cursor: pointer;
  text-align: relative; 
  position: absolute;
  right: 100px;
 top: 45px;
 text-decoration: none;
}

/* Darker background on mouse-over */
.btn:hover {
  background-color:burlywood;
  
}


         </style>
     <title>login pharmacist page</title>
 </head>
 <body>
 <button class="btn" onclick="document.location='index.html'"><i class="fa fa-home"></i> Home</button>
     <br>
     <h1><strong>P</strong><small>HARMACY</small> <strong>S</strong><small>HOP</small> <strong>M</strong><small>ANAGMENT</small> <strong>S</strong><small>YSTEM</small></h1>
     <h3>A complete solution to manage Pharmacy shop</h3>
     <br><br>
     
     <form  class= center action="loginpharmacist.php" method="post">
        <h2> Pharmacist Login</h2>
        <p>PHARMACIST_ID: <input name="PHARMACIST_ID" type="text" style="width:170px" placeholder="Pharmacist_id" required="required" id="PHARMACIST_ID"/> </p> 
        
        <p>PASSWORD: <input name="PASSWORD" type="text" style="width:170px" placeholder="Password" required="required" id="PASSWORD"/></p>
        
        
        <input  type="submit" name="login" value="login">
        
                
           
     </form>

    </body>

</html>