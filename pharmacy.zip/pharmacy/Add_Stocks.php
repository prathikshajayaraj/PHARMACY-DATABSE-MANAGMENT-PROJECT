<?php
$servername='localhost';
$username='root';
$password='';
$databasename = "pharmacy";
$conn=mysqli_connect($servername,$username,$password,$databasename);
if(!$conn)
{
die("connection failed:".mysqli_connect_error());
}
if(isset($_POST['Save']))
{
$Stock_ID = $_POST['Stock_ID'];
$Drug_Name = $_POST['Drug_Name'];
$Description= $_POST['Description'];
$Supplier = $_POST['Supplier'];
$Quantity = $_POST['Quantity'];
$Total_Cost = $_POST['Total_Cost'];

$Date_Supplied= $_POST['Date_Supplied'];

$sql_query ="insert into stocks(Stock_ID,Drug_Name,Description,Supplier,Quantity,Total_Cost,Date_Supplied)values('$Stock_ID','$Drug_Name','$Description','$Supplier','$Quantity','$Total_Cost','$Date_Supplied')";
if(mysqli_query($conn, $sql_query))
{
echo "Stocks has been updated!";
}
else
{
echo "Error:" . mysqli_error($conn);
}
mysqli_close($conn);
}
?>



<!Doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title> Add Stock page</title>
    <style>
        a {
            color: black;
            padding: 14px 25px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
        }

        h2 {
            color: black;
        }

        .center {
            background-color: white;
            opacity: 0.8;
            margin: auto;
            width: 25%;
            border: 1px solid black;
            padding: 10px;
        }

        form {
            text-align: center
        }

        .ad {
            text-align: relative;
            position: absolute;
            right: 100px;
            top: 45px;
        }

        body {
            background-image: url("images/1.jpg");
            background-color: #cccccc;
            height: 300px;
            background-repeat: no-repeat;
            background-size: cover;
        }
         a:link, a:visited {
  background-color: black;
  color: white;
  padding: 14px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  text-align: relative; 
                      position: absolute;
                       right: 100px;
                       bottom: 45px;
                       
}
                     a:active {
  background-color: black;}
    </style>
</head>
<body>
<a href="Stock.html" target="_blank">BACK</a>
    <div class="ad">
        <h1>ADD STOCK</h1>
    </div>
    <br>
    <h1><strong>P</strong><small>HARMACY</small> <strong>S</strong><small>HOP</small> <strong>M</strong><small>ANAGMENT</small> <strong>S</strong><small>YSTEM</small></h1>

    <div class="s">
        <h3>A complete solution to manage Pharmacy shop</h3>
    </div>

    

    <form class="center" action="Add_Stocks.php" method="POST">
        <h2> Add Stock</h2>
        <label for="Stock_ID"> Stock_ID: </label>
        <input type="text" id="Stock_ID" name="Stock_ID" Stock_Id="Stock_ID">
        <br><br>
        <label for="Drug_Name">Drug_Name : </label>
        <input type="text" id="Drug_Name" name="Drug_Name" Drug_Name="Drug_Name">
        <br><br>
        <label for="Description"> Description: </label>
        <input type="text" id="Description" name="Description" Description="Description">
        <br><br>
        <label for="Supplier"> Supplier: </label>
        <input type="text" id="Supplier" name="Supplier" Supplier="Supplier">
        <br><br>
        <label for="Quantity"> Quantity: </label>
        <input type="text" id="Quantity" name="Quantity" Quantity="Quantity">
        <br><br>
        <label for="Total_Cost"> Total_Cost: </label>
        <input type="text" id="Total_Cost" name="Total_Cost" Total_Cost="Total_Cost">
        <br><br>
      
        <label for="Date_Supplied"> Date_Supplied: </label>
        <input type="text" id="Date_Supplied" name="Date_Supplied" Date_Supplied="Date_Supplied">
        <br><br>


       <input type="submit" value="Save" name="Save">
    </form>
    </div>
</body>
</html>

