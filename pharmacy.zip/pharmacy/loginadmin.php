<?php
$servername='localhost';
$username='root';
$password='';
$databasename = "pharmacy";

$conn=mysqli_connect($servername,$username,$password,$databasename);
if(!$conn)  
{
die("connection failed:".mysqli_connect_error());
}else{
    if(isset($_POST['login']))
    {
        $ADMIN_ID= $_POST['ADMIN_ID'];
        $PASSWORD = $_POST['PASSWORD'];
        $sql=mysqli_query($conn,"SELECT * FROM admin where ADMIN_ID ='$ADMIN_ID' and  PASSWORD='$PASSWORD'");
        
        
        $row  = mysqli_fetch_array($sql);
        if(is_array($row))
        {
            
            $_SESSION["ADMIN_ID"]=$row['ADMIN_ID'];
            $_SESSION["PASSWORD"]=$row['PASSWORD'];
            echo "login successfull";
            header("Location:admin.html"); 
}
else 
{
echo "login unsuccessful";
header("Location:loginadmin.php"); 
}
mysqli_close($conn);
}
        
    }

?>
<!DOCTYPE html>
<html>
 <head><meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     <style> 
     
          h1{
              color: black;
              font-family: "Times New Roman", Times, serif;
          }
          h3{
               color: black;
               line-height: 0.1;
               font-family: Copperplate, Papyrus, fantasy;
                     
             }
          
                .center{
                    background-color:white;
                    opacity: 0.8;
                    margin: auto;
                    width : 25%;
                    border: 1px solid black;
                    padding: 10px;
                }
                
            form{
                text-align: center
                }  
                body {
                       background-image: url("images/11.jpg");
                       background-color: #cccccc;
                       height: 300px;
                       background-repeat: no-repeat;
                       background-size: cover;
                    }
                    .ad{
                      text-align: relative; 
                      position: absolute;
                       right: 100px;
                       top: 45px;

                    }
                    .btn {
  background-color:whitesmoke;
  border: none;
  color: black;
  padding: 12px 16px;
  font-size: 16px;
  cursor: pointer;
  text-align: relative; 
  position: absolute;
  right: 100px;
 top: 45px;
 text-decoration: none;
}

/* Darker background on mouse-over */
.btn:hover {
  background-color:#ADD8E6;
  
}


         </style>
     <title>login admin page</title>
 </head>
 <body>
 <button class="btn" onclick="document.location='index.html'"><i class="fa fa-home"></i> Home</button>
     
     <br>
     <h1><strong>P</strong><small>HARMACY</small> <strong>S</strong><small>HOP</small> <strong>M</strong><small>ANAGMENT</small> <strong>S</strong><small>YSTEM</small></h1>
     <h3>A complete solution to manage Pharmacy shop</h3>
     <br><br>
     
     <form  class= center action="loginadmin.php" method="post">
        <h2> Admin Login</h2>
        <p>ADMIN_ID: <input name="ADMIN_ID" type="text" style="width:170px" placeholder="Admin_id" required="required" id="ADMIN_ID"/> </p> 
        
        <p>PASSWORD: <input name="PASSWORD" type="text" style="width:170px" placeholder="Password" required="required" id="PASSWORD"/></p>
        
        
        <input  type="submit" name="login" value="login">

     </form>

    </body>

</html>