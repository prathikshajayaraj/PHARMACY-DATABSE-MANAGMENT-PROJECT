
<!Doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">


    <title>Pharmacist page</title>
    <style>
        a {
            color: black;
            padding: 14px 25px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
        }

        h2 {
            color: black;
        }

        body {
            background-image: url("images/1.jpg");
            background-color: #cccccc;
            height: 300px;
            background-repeat: no-repeat;
            background-size: cover;
        }

        .right {
            background-color: white;
            opacity: 0.8;
            margin: auto;
            border: 1px solid black;
            padding: 10px;
            text-align: center;
            height: 90px;
            width: 200px;
        }

        .left {
            background-color: white;
            opacity: 0.8;
            margin: auto;
            height: 90px;
            width: 200px;
            border: 1px solid black;
            padding: 10px;
            text-align: center;
        }

        .s {
            color: black;
            line-height: 0.1;
            font-family: Copperplate, Papyrus, fantasy;
        }

        @import url(https://fonts.googleapis.com/css?family=Oswald:400);

        .navigation {
            width: 100%;
            background-color: black;
            opacity: 0.9;
            position: center;
        }

        .logout {
            font-size: .8em;
            font-family: 'Oswald', sans-serif;
            position: center;
            right: -18px;
            bottom: -4px;
            overflow: hidden;
            letter-spacing: 3px;
            opacity: 0;
            transition: opacity .45s;
            -webkit-transition: opacity .35s;
        }

        .button {
            text-decoration: none;
            float: right;
            padding: 12px;
            margin: 15px;
            color: white;
            width: 25px;
            background-color: black;
            transition: width .35s;
            -webkit-transition: width .35s;
            overflow: hidden
        }

        a:hover {
            width: 100px;
        }

            a:hover .logout {
                opacity: .9;
            }

        a {
            text-decoration: none;
        }

        .ad {
            text-align: relative;
            position: absolute;
            right: 100px;
            top: 45px;
        }
    </style>
</head>
<body>
    <div class="ad">
        <h1>PHARMACIST</h1>
    </div>
    <br><br>
    <h1><strong>P</strong><small>HARMACY</small> <strong>S</strong><small>HOP</small> <strong>M</strong><small>ANAGMENT</small> <strong>S</strong><small>YSTEM</small></h1>

    <div class="s">
        <h3>A complete solution to manage Pharmacy shop</h3>
    </div>

    <br>

    <div class="right">
        <h2>
            <a href="Prescription.html">
                Prescription
            </a>
        </h2>
    </div>
    <div class="left">
        <h2>
            <a href="Stock.html">
                Stock
            </a>
        </h2>
    </div>
    <div class="navigation">

        <a class="button" href="index.html">

            <div class="logout">LOGOUT</div>

        </a>

    </div>




</body>


</html>
