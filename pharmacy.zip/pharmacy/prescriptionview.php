<?php
$servername='localhost';
$username='root';
$password='';
$databasename = "pharmacy";
$conn=mysqli_connect($servername,$username,$password,$databasename);
if(!$conn)  
{
die("connection failed:".mysqli_connect_error());
}

?>
<!DOCTYPE html>
<html>
    <head>
    
        <title>pharmacist view prescription </title>
        <?php include 'links.php' ;?>
        <link rel="stylesheet" href="style.css">
        <style>
        .ad{
            
                      position: absolute;
                       right: 100px;
                       bottom: 45px;
                       font-size: 150%;
                       background-color: black;
                       
  
  padding: 10px 15px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  
}
        </style>
      
    <body>
   <div class ="ad"> <a href="Pharmacist.php" target="_blank">BACK</a></div>
        <div class="main-div">
            
            <h1>Prescriptions list</h1>
            <div  class="center-div">
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Prescription_ID </th>
                                <th>Customer_Name </th>
                                <th>Customer_ID</th>
                                <th>Order_Date</th>

                                <th>Phone</th>
                                <th>Dose</th>
                                <th>Drug_Name</th>
                                <th>Strength</th>
                                <th>Total_Amount</th>
                               
                                <th>UPDATE</th>
                                <th>DELETE</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                        $selectquery="select * from prescription ";
                        $query=mysqli_query($conn,$selectquery);
                         $nums=mysqli_num_rows($query);

                         

                        while($res= mysqli_fetch_array($query))
                        {
                            ?>
                            <tr>
                            <td><?php echo $res['Prescription_ID'];?></td>
                            <td><?php echo $res['Customer_Name'];?></td>
                            <td><?php echo $res['Customer_ID'];?></td><td>
                                <?php echo $res['Date'];?></td>
                           
                            <td><?php echo $res['Phone'];?></td>
                            <td><?php echo $res['Dose'];?></td>
                            <td><?php echo $res['Drug_Name'];?></td>
                            <td><?php echo $res['Strength'];?></td>
                            <td><?php echo $res['Total_Amount'];?></td>
                           
                            
                            <td><a href="prescriptionupdate.php?Prescription_ID=<?php echo $res['Prescription_ID']; ?>" data-toggle="tooltip" data-placement="bottom" title="Update"><i class="fa fa-edit" aria-hidden="true"></i></a></td>
                            <td><a href="prescriptiondelete.php?Prescription_ID=<?php echo $res['Prescription_ID']; ?>" data-toggle="tooltip" data-placement="bottom" title="Delete"><i class="fa fa-trash" aria-hidden="true"></i></a></td>
                            
                           </tr>
                           <?php
                        }
                        
                         ?>
                           
                        </tbody>
                    </table>


                </div>
            </div>
        </div>
        
    </body>
    <script>
$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();
});
</script>
</html>