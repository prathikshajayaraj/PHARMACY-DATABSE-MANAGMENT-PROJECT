-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 28, 2022 at 10:29 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ppms`
--

-- --------------------------------------------------------

--
-- Table structure for table `prescription`
--

CREATE TABLE `prescription` (
  `Prescription_ID` int(10) NOT NULL,
  `Customer_Name` varchar(20) NOT NULL,
  `Customer_ID` int(10) NOT NULL,
  `Date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Phone` bigint(10) NOT NULL,
  `Dose` varchar(15) NOT NULL,
  `Drug_Name` varchar(20) NOT NULL,
  `Strength` int(10) NOT NULL,
  `Total_Amount` int(10) NOT NULL,
  `Quantity` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `prescription`
--

INSERT INTO `prescription` (`Prescription_ID`, `Customer_Name`, `Customer_ID`, `Date`, `Phone`, `Dose`, `Drug_Name`, `Strength`, `Total_Amount`, `Quantity`) VALUES
(2111, 'Ananya', 333, '2022-01-27 17:30:21', 9876543210, '5', 'Dolo 650', 6, 500, 60),
(3002, 'Navya', 0, '0000-00-00 00:00:00', 7406150450, '2', 'Dolo', 6, 50, 3),
(3004, 'Saksha', 1, '0000-00-00 00:00:00', 9876543021, '2', 'Paracetomol', 6, 80, 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `prescription`
--
ALTER TABLE `prescription`
  ADD PRIMARY KEY (`Prescription_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `prescription`
--
ALTER TABLE `prescription`
  MODIFY `Prescription_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3005;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
