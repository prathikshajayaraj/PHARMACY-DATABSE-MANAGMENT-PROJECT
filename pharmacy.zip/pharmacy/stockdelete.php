<?php
$servername='localhost';
$username='root';
$password='';
$databasename = "pharmacy";
$conn=mysqli_connect($servername,$username,$password,$databasename);
if(!$conn)  
{
die("connection failed:".mysqli_connect_error());
}
$stockid=$_GET['Stock_ID'];
$deletequery=" delete from stocks where Stock_ID=$stockid";
$query=mysqli_query($conn,$deletequery);
if($query){
    ?>
    <script>
        alert("Deleted sucesfully");
        </script>
<?php
} else{
    ?>
    <script>
        alert(" Not Deleted");
        </script>
        <?php
}
header('location:stockview.php');
?>