<?php
$servername='localhost';
$username='root';
$password='';
$databasename = "pharmacy";
$conn=mysqli_connect($servername,$username,$password,$databasename);
if(!$conn)
{
die("connection failed:".mysqli_connect_error());
}
if(isset($_POST['submit']))
{

$Prescription_ID = $_POST['Prescription_ID'];
$Customer_Name = $_POST['Customer_Name'];
$Customer_ID = $_POST['Customer_ID'];
$Date=$_POST['Date'];
$Phone = $_POST['Phone'];
$Dose = $_POST['Dose'];
$Drug_Name = $_POST['Drug_Name'];
$Strength = $_POST['Strength'];
$Total_Amount = $_POST['Total_Amount'];


$sql_query ="insert into prescription(Prescription_ID ,Customer_Name ,Customer_ID ,Date,Phone,Dose,Drug_Name,Strength,Total_Amount) values('$Prescription_ID','$Customer_Name','$Customer_ID','$Date','$Phone','$Dose','$Drug_Name','$Strength','$Total_Amount')";
if(mysqli_query($conn, $sql_query))
{
echo "Presciption has been updated!";
}
else
{
echo "Error: " . mysqli_error($conn);
}

}
?>



<!Doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title> Add Prescription page</title>
    <style>
        a {
            color: black;
            padding: 14px 25px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
        }

        h2 {
            color: black;
        }

        .center {
            background-color: white;
            opacity: 0.8;
            margin: auto;
            width: 32%;
            border: 1px solid black;
            padding: 10px;
        }

        form {
            text-align: center
        }

        .ad {
            text-align: relative;
            position: absolute;
            right: 100px;
            top: 45px;
        }

        body {
            background-image: url("images/222.jpeg");
            background-color: #cccccc;
            height: 300px;
            background-repeat: no-repeat;
            background-size: cover;
        }

        .x {
            text-align: relative;
            position: absolute;
            right: 100px;
            bottom: 45px;
        }
         a:link, a:visited {
  background-color: black;
  color: white;
  padding: 14px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  text-align: relative; 
                      position: absolute;
                       right: 100px;
                       bottom: 45px;
                       
}
                     a:active {
  background-color: black;}
    </style>
</head>
<body>
 <a href="Prescription.html" target="_blank">BACK</a>
    <div class="ad">
        <h1>ADD PRESCRIPTION</h1>
    </div>
    <br>
    <h1><strong>P</strong><small>HARMACY</small> <strong>S</strong><small>HOP</small> <strong>M</strong><small>ANAGMENT</small> <strong>S</strong><small>YSTEM</small></h1>

    <div class="s">
        <h3>A complete solution to manage Pharmacy shop</h3>
    </div>

    

    
        <div class="center">
        <form actions="Add_Prescription.php" method="post">
               <p>Prescription_ID:<input name="Prescription_ID" type="text" style="width:170px" placeholder="Prescription_ID" required="required" id="Prescription_ID"/> </p> 
                <p>Customer_Name: <input name="Customer_Name" type="text" style="width:170px" placeholder="Customer_Name" required="required" id="CustomerName" /></p>
                <p>Customer_ID: <input name="Customer_ID" type="text" style="width:170px" placeholder="Customer_ID" required="required" id="CustomerID" /></p>
                <p >Date: <input name="Date" type="text" style="width:170px"placeholder="Date"  required="required" id="date"/></p>  
	        <p >Phone:<input name="Phone" type="text" style="width:170px" placeholder="Phone" required="required" id="phone"/> </p> 
            <p >Dose:<input name="Dose" type="text" style="width:170px" placeholder="Dose" required="required" id="dose"/> </p> 
           Drug Name: 
       
           <?php
           $query=mysqli_query($conn,"select * from stocks");
           $rowcount=mysqli_num_rows($query);
           ?>
               <select name="Drug_Name">
        
               <option value="">Select Any one</option>
               <?php
               for($i=1;$i<=$rowcount;$i++)
               {
                   $row=mysqli_fetch_array($query);
              
               ?>
               <option value="<?php echo $row["Drug_Name"] ?>"><?php echo $row["Drug_Name"]?>
               </option>
               <?php
               }
               mysqli_close($conn);
               ?>
           </select>
            </p>
             <p>Strength:<input name="Strength" type="text" style="width:170px" placeholder="Strength" required="required" id="strength"/> </p> 
            <p >Total_Amount:<input name="Total_Amount" type="text" style="width:170px" placeholder="Total_Amount" required="required" id="TotalAmount"/> </p> 
          
          <p><input name="submit" type="submit" value="submit"/></p>
           
		</form>
        </div>



    </form>
    </div>
    <div class="x">
       
    </div>
</body>
</html>

